public class Giocatore extends Thread{
    private String nome;
    private int punteggio;


    public Giocatore(String nome){
        this.punteggio=0;
        this.nome=nome;
    }
    public void stampa(){
        System.out.println("sono il giocatore" + nome);
    }

    public int getPunteggio() {
        return punteggio;
    }
    public String getNome(){
        return nome;
    }

    @Override
    public void run(){
        try {
            sleep(5000);
        } catch (InterruptedException e) {
            System.err.println("errore");
        }
        stampa();
        super.run();


    }
}
